# task 2
USE TRAVEGO;
#2a a. How many female passengers traveled a minimum distance of 600 KMs? 
SELECT COUNT(GENDER) FROM PASSENGER WHERE DISTANCE >=600 AND GENDER = 'F';

#2b. Write a query to display the passenger details whose travel distance is greater than 500 and who are traveling in a sleeper bus.
SELECT * FROM PASSENGER WHERE DISTANCE>500 AND BUS_TYPE = 'SLEEPER';

#2c. Select passenger names whose names start with the character 'S'   
SELECT PASSENGER_NAME FROM PASSENGER WHERE PASSENGER_NAME LIKE 'S%';
      
#2d. Calculate the price charged for each passenger, displaying the Passenger name, Boarding City,Destination City, Bus type, and Price in the output.
SELECT P.PASSENGER_NAME,P.BOARDING_CITY,P.DESTINATION_CITY,P.BUS_TYPE,PR.PRICE FROM PASSENGER P
LEFT JOIN PRICE PR ON P.BUS_TYPE = PR.BUS_TYPE AND P.DISTANCE = PR.DISTANCE;  

#2e. What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus?
select p.passenger_name,pr.price from passenger p join price pr on p.bus_type = pr.bus_type and p.distance = pr.distance 
where p.distance = 1000 and p.Bus_type = 'sitting'; 
#there is no data where distance is 1000 and bus type is sitting so no data is returned

#2f.What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji? 
#since there are no buses with boarding station as banglore and destination station as panaji
SELECT PASSENGER.BUS_TYPE, PASSENGER_NAME,PRICE FROM PASSENGER INNER JOIN PRICE
ON PASSENGER.PASSENGER_ID = PRICE.ID WHERE BOARDING_CITY ='panaji' AND DESTINATION_CITY = 'Bengaluru' AND 
PASSENGER_NAME ='pallavi'; 

#2g. Alter the column category with the value "Non-AC" where the Bus_Type is sleeper
UPDATE PASSENGER SET CATEGORY='Non_AC' WHERE BUS_TYPE = 'sleeper';  
select * from passenger;
rollback; 

#2h. Delete an entry from the table where the passenger name is Piyush and commit this change in the database
DELETE FROM PASSENGER WHERE PASSENGER_NAME ='piyush';
select * from passenger;
commit;

#2i.Truncate the table passenger and comment on the number of rows in the table (explain if required).  
SELECT * FROM PASSENGER; #there are 8 rows of data before truncating the passenger table
TRUNCATE TABLE PASSENGER;
SELECT * FROM PASENGER; #there is no passenger table that exists
rollback;

#2j. Delete the table passenger from the database
DROP TABLE PASSENGER; 
    